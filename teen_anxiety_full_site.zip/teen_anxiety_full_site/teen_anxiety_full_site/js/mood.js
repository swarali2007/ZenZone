
document.getElementById("moodForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const mood = this.mood.value;
  const note = this.note.value;
  const log = document.getElementById("moodLog");
  const entry = document.createElement("div");
  entry.innerText = `Mood: ${mood} - ${note}`;
  log.appendChild(entry);
  this.reset();
});
