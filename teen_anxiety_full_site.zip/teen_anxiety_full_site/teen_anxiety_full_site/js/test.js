
document.getElementById("testForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let score = 0;
  for (let i = 1; i <= 7; i++) {
    const val = document.querySelector(`input[name='q${i}']:checked`);
    if (val) score += parseInt(val.value);
  }
  localStorage.setItem("gad7Score", score);
  window.location.href = "results.html";
});
