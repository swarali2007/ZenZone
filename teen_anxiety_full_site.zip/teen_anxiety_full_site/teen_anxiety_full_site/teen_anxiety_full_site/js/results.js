
window.onload = () => {
  const { jsPDF } = window.jspdf;
  const score = localStorage.getItem("gad7Score") || 0;
  document.getElementById("score").innerText = score;

  let interpretation = "";
  if (score <= 4) interpretation = "Minimal anxiety";
  else if (score <= 9) interpretation = "Mild anxiety";
  else if (score <= 14) interpretation = "Moderate anxiety";
  else interpretation = "Severe anxiety";

  document.getElementById("interpretation").innerText = interpretation;

  window.downloadPDF = () => {
    const doc = new jsPDF();
    doc.text("GAD-7 Report", 10, 10);
    doc.text("Score: " + score, 10, 20);
    doc.text("Interpretation: " + interpretation, 10, 30);
    doc.save("report.pdf");
  };
};
