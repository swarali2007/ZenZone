
function startTimer() {
  let time = 60;
  const el = document.getElementById("timer");
  const interval = setInterval(() => {
    el.innerText = time;
    time--;
    if (time < 0) {
      clearInterval(interval);
      el.innerText = "Done!";
    }
  }, 1000);
}
